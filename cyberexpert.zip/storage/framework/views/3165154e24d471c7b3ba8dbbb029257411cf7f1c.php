<div class="row">
    <div class="col-lg-6 col-md-6">

    </div>
    <div class="col-lg-6 col-md-6">
        <div class="footer">
            <p>2023 © Admin Panel. - <a href="https://github.com/ismail306">Ismail Hossain</a></p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/components/admin/layouts/partials/footer.blade.php ENDPATH**/ ?>