<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.users.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('users.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Specialist
         <?php $__env->endSlot(); ?>

        <div class="container">
            <div class="row sp_list">
                <div class="col-lg-12">
                    <h1>Security Specialist List</h1>


                </div>
            </div>



            <div class="row">

                <div class="col-md-4">
                    <div class="card user-card">
                        <div class="card-header">
                            <h5>Profile</h5>
                        </div>
                        <div class="card-block">
                            <div class="user-image">
                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius" alt="User-Profile-Image">
                            </div>
                            <h6 class="f-w-600 m-t-5 m-b-5">Alessa Robert</h6>
                            <p>Web pentester</p>

                            <hr>
                            <p class="m-t-5">Activity Level: 87%</p>
                            <ul class="list-unstyled activity-leval">
                                <li class="active"></li>
                                <li class="active"></li>
                                <li class="active"></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <div class="bg-c-blue counter-block m-t-10 p-20">
                                <div class="row">

                                    <div class="col-8 ">
                                        <i class="fa fa-phone"> 01929074663</i>

                                    </div>
                                    <div class="col-4">
                                        <a href="" data-toggle="modal" data-target="#contact"><i class="fa fa-paper-plane"></i></a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card user-card">
                        <div class="card-header">
                            <h5>Profile</h5>
                        </div>
                        <div class="card-block">
                            <div class="user-image">
                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius" alt="User-Profile-Image">
                            </div>
                            <h6 class="f-w-600 m-t-5 m-b-5">Alessa Robert</h6>
                            <p>Web pentester</p>

                            <hr>
                            <p class="text-muted m-t-5">Activity Level: 87%</p>
                            <ul class="list-unstyled activity-leval">
                                <li class="active"></li>
                                <li class="active"></li>
                                <li class="active"></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <div class="bg-c-blue counter-block m-t-10 p-20">
                                <div class="row">

                                    <div class="col-8 ">
                                        <i class="fa fa-phone"> 01929074663</i>

                                    </div>

                                    <div class="col-4">
                                        <a href="" data-toggle="modal" data-target="#contact"><i class="fa fa-paper-plane"></i></a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card user-card">
                        <div class="card-header">
                            <h5>Profile</h5>
                        </div>
                        <div class="card-block">
                            <div class="user-image">
                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius" alt="User-Profile-Image">
                            </div>
                            <h6 class="f-w-600 m-t-5 m-b-5">Alessa Robert</h6>
                            <p>Web pentester</p>

                            <hr>
                            <p class="text-muted m-t-5">Activity Level: 87%</p>
                            <ul class="list-unstyled activity-leval">
                                <li class="active"></li>
                                <li class="active"></li>
                                <li class="active"></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <div class="bg-c-blue counter-block m-t-10 p-20">
                                <div class="row">

                                    <div class="col-8 ">
                                        <i class="fa fa-phone"> 01929074663</i>

                                    </div>

                                    <div class="col-4">
                                        <a href="" data-toggle="modal" data-target="#contact"><i class="fa fa-paper-plane"></i></a>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/securityspecialist/specialist.blade.php ENDPATH**/ ?>