<section>
    <header class="ml-3">
        <h3 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Become a certified cyber security specialist')); ?>

        </h3>
    </header>


    <form method="post" action="<?php echo e(route('specialistinfo.store')); ?>" class="mt-6 space-y-6" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-4">
            <label for="about">About </label>
            <?php if(isset($users->about)): ?>
            <textarea class="form-control" name="about" required id="about" rows="2" maxlength="75" placeholder=""><?php echo e($users->about); ?></textarea>
            <?php else: ?>
            <textarea class="form-control" name="about" id="about" rows="2" maxlength="75" placeholder="About Yourself ..."></textarea>
            <?php endif; ?>

            <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="certificate">Certificate</label>
            <input type="file" required name="certificate" class="form-control" id="certificate" aria-describedby="emailHelp">
            <?php $__errorArgs = ['certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        </div>

        <div class="d-flex justify-content-end mt-5">
            <button type="submit" class="btn  btn-success mb-2 btn-pill">Submit</button>
            <button type="reset" class="btn  btn-danger mb-2 ml-3 btn-pill">Discard All</button>
        </div>


    </form>

</section><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/components/users/layouts/partials/specialistapplication.blade.php ENDPATH**/ ?>