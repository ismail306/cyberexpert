<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.users.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('users.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        .card {
            width: auto;
            margin: 50px auto;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
        }

        .omb_loginForm {
            padding: 10px;
        }
    </style>
    <div class="container bootstrap snippets bootdey">


        <div class=" card omb_login">
            <h3 class="  omb_authTitle">Create an account</h3>

            <div class="row omb_row-sm-offset-3">
                <div class="col-xs-12 col-sm-6">
                    <form method="POST" name='signinform' onsubmit="return validateform()" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-outline input-group mb-2">
                            <span class="input-group-addon pt-1 pr-1"><i class="fa fa-user"></i></span>
                            <input type="text" required name="name" class=" form-control" placeholder="Name" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-outline input-group mt-3 mb-2">
                            <span class="input-group-addon pt-1 pr-1"><i class="fa fa-phone"></i></span>
                            <input type="tel" class="form-control" required name="phone" pattern="[0-1]{2}[3,4,5,6,7,8,9]{1}[0-9]{8}" placeholder="01(3-9)xxxxxxxx">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-outline mt-3 input-group mb-2">
                            <span class="input-group-addon pt-1 pr-1"><i class="fa fa-envelope"></i></span>
                            <input type="email" required name="email" class="form-control" placeholder="Email" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="form-outline input-group mt-3 mb-2">
                            <span class="input-group-addon pt-1 pr-1"><i class="fa fa-lock"></i></span>
                            <input type="password" required name="password" class="form-control" placeholder="Password" />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-outline mt-3 mb-2 input-group">

                            <span class="input-group-addon pt-1 pr-1"><i class="fa fa-lock"></i></span>
                            <input type="password" required name="password_confirmation" class="form-control" placeholder="Repeat password" />
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>
                        <div>
                            <p class="ml-3" id="passvalidation" style="color:red"></p>
                        </div>

                        <div class="form-check d-flex justify-content-center mb-2">
                            <input class="form-check-input checkposition mb-1 mr-2" type="checkbox" value="" id="termsCheckbox" />
                            <label class="form-check-label" for="termsCheckbox">
                                I agree all statements in <a href="#!" class="text-body"><u>Terms of service</u></a>
                            </label>
                        </div>

                        <div class="d-flex justify-content-center">
                            <button type="submit" id="registerButton" disabled class="btn  btn-success btn gradient-custom-4 ">Register</button>
                        </div>

                        <p class="text-center text-muted mt-3 mb-4">Have already an account? <a href="<?php echo e(route('login')); ?>" class="fw-bold text-body"><u>Login here</u></a></p>

                    </form>
                </div>
            </div>




        </div>
    </div>





 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/auth/register.blade.php ENDPATH**/ ?>