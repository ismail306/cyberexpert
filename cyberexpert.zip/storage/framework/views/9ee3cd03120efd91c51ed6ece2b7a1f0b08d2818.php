<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e($title ?? 'Dashboard | users'); ?>

     <?php $__env->endSlot(); ?>



    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">

                    <!-- /# column -->
                    <div class="col-lg-12 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Users</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>
                <!-- /# row -->
                <section id="main-content">

                    <div class="row">
                        <div class="col-lg-12 col-md-12 p-r-0 title-margin-right">
                            <div class="page-header">
                                <div class="page-title text-center">
                                    <h3>Requested Users for Certified</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="jsgrid-table-panel">
                                    <div id="jsGrid">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Certificate</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="modal fade" id="approved<?php echo e($certificate->user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <form action="<?php echo e(route('certificate.review')); ?>" method="post">
                                                            <?php echo method_field('GET'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="text" name="id" hidden value="<?php echo e($certificate->user->id); ?>">
                                                            <div class="modal-content">
                                                                <div class="modal-header">

                                                                    <h5 class="modal-title" id="exampleModalLongTitle">
                                                                        Approved User request </h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Name: <?php echo e($certificate->user->name); ?> </p>
                                                                    <p>Email: <?php echo e($certificate->user->email); ?></p>

                                                                    <div class="form-group text-success">
                                                                        <label for="exampleFormControlSelect1">Change
                                                                            Role To: certified User </label>
                                                                        <input hidden type="text" name="status" value="approved">

                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Save
                                                                        changes</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>



                                                <div class="modal fade" id="rejected<?php echo e($certificate->user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <form action="<?php echo e(route('certificate.review')); ?>" method="post">
                                                            <?php echo method_field('GET'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="text" name="id" hidden value="<?php echo e($certificate->user->id); ?>">
                                                            <div class="modal-content">
                                                                <div class="modal-header">

                                                                    <h5 class="modal-title" id="exampleModalLongTitle">
                                                                        Approved User request </h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Name: <?php echo e($certificate->user->name); ?> </p>
                                                                    <p>Email: <?php echo e($certificate->user->email); ?></p>

                                                                    <div class="form-group text-success">
                                                                        <label for="exampleFormControlSelect1">Request Wiill Rejected </label>
                                                                        <input hidden type="text" name="status" value="rejected">

                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Save
                                                                        changes</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>


                                                <tr>
                                                    <th><?php echo e($loop->iteration); ?></th>
                                                    <td><?php echo e($certificate->user->name); ?></td>
                                                    <td><?php echo e($certificate->user->email); ?></td>
                                                    <td>
                                                        <?php if($certificate->status == "approved"): ?>
                                                        <span class="badge badge-success">Approved</span>
                                                        <?php elseif($certificate->status == "pending"): ?>

                                                        <span class="badge badge-secondary">Pending</span>

                                                        <?php elseif($certificate->status == "rejected"): ?>
                                                        <span class="badge badge-danger">Rejected</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(asset('storage/images/certificates/' . $certificate->url)); ?>" class="btn btn-primary">Download Certificate</a>
                                                    </td>

                                                    <td>
                                                        <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#approved<?php echo e($certificate->user->id); ?>">Approved</a>
                                                        <a href="" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#rejected<?php echo e($certificate->user->id); ?>">Reject</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4">

                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>


                    <!-- Footer will be here -->



                </section>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/admin/certificate.blade.php ENDPATH**/ ?>