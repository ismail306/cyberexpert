<div class="col-lg-5 col-xl-4">
    <div class="profile-content-left profile-left-spacing pt-5 pb-3 px-3 px-xl-5">
        <div class="card text-center widget-profile px-0 border-0">
            <div class="card-img mx-auto">
                <?php if(isset($users->profile_pic)): ?>
                <img src="<?php echo e(asset('/storage/images/profile_pics/' . $users->profile_pic)); ?>" class="rounded-circle" alt="user image" width="100px">
                <?php else: ?>
                <img src="<?php echo e(asset('/user/images/users/profile.jpg')); ?>" class="rounded-circle" alt="user image" width="100px">
                <?php endif; ?>
            </div>

            <div class=" card-body">
                <h4 class="py-2 text-dark"><?php echo e(isset($users->name)?$users->name:""); ?>

                    <?php if(isset($users)): ?>
                    <?php if($users->role=='certified'): ?>
                    <span class="text-success ml-2"><i class="fas fa-user-shield"></i></span>
                    <?php elseif($users->role=='user'): ?>
                    <span class="text-primary ml-2"><i class="fas fa-user"></i></span>
                    <?php elseif($users->role=='admin'): ?>
                    <span class="text-warning ml-2"><i class="fas fa-user-circle"></i></span>
                    <?php endif; ?>
                    <?php endif; ?>
                </h4>
                <div class=" px-3">
                    <p><?php echo e(isset($users->about)?$users->about:""); ?></p>
                </div>

            </div>
        </div>


        <div class="contact-info pt-2">
            <h4 class="text-dark mb-1">Contact Information</h4>
            <div class="">
                <span><i class="fa fa-envelope pr-2"></i><?php echo e(isset($users->email)?$users->email:""); ?> </span>
            </div>

            <div>
                <span><i class="fa fa-phone pr-2"> </i><?php echo e(isset($users->phone)?$users->phone:""); ?> </span>

            </div>
        </div>

        <div class="card mt-4 px-2 pt-3 text-center border border-primary">
            <h3><a href="<?php echo e(route('specialist.applications')); ?>">Apply to become a certified specialist</a></h3>
        </div>

        <div class="card">
            <?php if(isset($blogs)): ?>
            <h3 class="ml-2 mt-4 pt-1 text-center">My Blogs</h3>

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h5 class=" ml-2 mb-4 ">
                <a href="<?php echo e(route('blog.readfull', $blog->id)); ?>" class="blog-title ">
                    <?php echo e($blog->title); ?></a>

            </h5>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/components/users/layouts/partials/profileinfo.blade.php ENDPATH**/ ?>