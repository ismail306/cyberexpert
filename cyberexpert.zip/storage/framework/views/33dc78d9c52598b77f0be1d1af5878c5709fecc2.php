<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.users.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('users.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> 
        404
         <?php $__env->endSlot(); ?>

        <div>
            <main>
                <section class="py-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-10 mx-auto text-center">
                                <img loading="lazy" decoding="async" src="<?php echo e(asset('/user/images/404.png')); ?>" alt="404" class="img-fluid mb-4" width="500" height="350">
                                <?php if(Session::has('message')): ?>
                                <h1 class="mb-4"><?php echo e(Session::get('message')); ?></h1>
                                <?php else: ?>
                                <h1 class="mb-4">Page Not Found!</h1>
                                <?php endif; ?>
                                <a href="<?php echo e(route('cyberexpert')); ?>" class="btn btn-outline-primary">Back To Home</a>
                            </div>
                        </div>

                    </div>
                </section>
            </main>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\cyberexpert\resources\views/users/404.blade.php ENDPATH**/ ?>