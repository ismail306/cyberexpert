<x-users.layouts.master>
    <x-slot:title>
        Broken|Authentication
        </x-slot>


</x-users.layouts.master>