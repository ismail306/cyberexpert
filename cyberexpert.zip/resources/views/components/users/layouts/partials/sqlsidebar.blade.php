<div class="card xssmenu " style="width: 18rem;">

    <ul class="list-group list-group-flush ">

        <li class="borderlist list-group-item"><a href="">Create Users For Practice</a> </li>
        <li>

        </li>

    </ul>

    <form action="{{ route('seed-database') }}" method="GET">
        <button type="submit" class="btn btn-primary">Seed Database</button>
    </form>
</div>