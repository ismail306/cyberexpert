<div class="card xssmenu " style="width: 18rem;">

    <ul class="list-group list-group-flush ">
        <li class=" borderlist list-group-item "><a href="{{route('reflectedxss')}}">Reflected XSS</a></li>
        <li class="borderlist list-group-item"><a href="{{route('storedxss')}}">Stored XSS</a> </li>

    </ul>
</div>