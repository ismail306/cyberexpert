<!-- Javascript Files
  ================================================== -->

<!-- initialize jQuery Library -->
<script src="{{asset('user/plugins/jQuery/jquery.min.js')}}"></script>
<!-- Bootstrap jQuery -->
<script src="{{asset('user/plugins/bootstrap/bootstrap.min.js')}}" defer></script>
<!-- Slick Carousel -->
<script src="{{asset('user/plugins/slick/slick.min.js')}}"></script>
<script src="{{asset('user/plugins/slick/slick-animation.min.js')}}"></script>
<!-- Color box -->
<script src="{{asset('user/plugins/colorbox/jquery.colorbox.js')}}"></script>
<!-- shuffle -->
<script src="{{asset('user/plugins/shuffle/shuffle.min.js')}}" defer></script>

<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote.js'></script> -->

<!-- Template custom -->
<script src="{{asset('user/js/script.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote.js"></script>